

<html>

	 <title> Login Page </title>

<head>
<body style="background: url(https://cdn.pixabay.com/photo/2017/05/15/17/43/cup-2315554_960_720.jpg)">
	<h1> login Page </h1> 
</head>
<form method= "POST" action="#"> 
<p>
e-mail: <input type="text" name="email" value="" id="email" placeholder=" Email"  /> <br> <br>
password: <input type="password" name="password" value="" id="password" placeholder="Password" /> <br> <br>
 

</p>
<p class="submit">
    <input type="submit" name="submit" value="login" onclick=" validate();" />    
</p>

</form>

<script>
    function validate() {
    	var text= document.getElementById("email").value;
	var regx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

        if (document.getElementById("email").value == "") {
            alert("e-mail may not be blank");
                  }  
        if (document.getElementById("password").value == "") {
            alert("Password may not be blank.");
                   
               } 

	if(!(regx.test(text))){

alert("invalid mail format");
  
	}

    }
</script>

</body>
</html>


<?php
 session_start();
 
 if(isset($_POST['submit']))
 { 
  $con=mysqli_connect('localhost','root','','users') or die(mysqli_error());

  //$username=$_POST['username'];
  $email=$_POST['email'];
 



$password = mysqli_real_escape_string($con, $_POST['password']);
 $password = md5($password);


  if($email!=''&&$password!='')              //and username='".$username."'
  {
  $query=mysqli_query($con,"SELECT * FROM tableofusers WHERE email='".$email."' and password='".$password."'  ") or die(mysqli_error());

    $res=mysqli_fetch_row($query);
    if($res){
     
    $queryTwo=mysqli_query($con, "SELECT username FROM tableofusers WHERE email='".$email."' ");

     $result = mysqli_fetch_row($queryTwo);
     //echo [$result];

     header('location:welcome.php');
     $_SESSION['username']=$result;
    // $_SESSION['email']=$email;
     //  	print_r( $_SESSION ); 

    }
    else
    {
     echo'Incorrect e-mail or password';
    }
  }


  
 }

 
   