

<!DOCTYPE html>
<html lang ="en">

<body style="background: url(https://cdn.pixabay.com/photo/2016/10/13/16/40/green-1738220_960_720.jpg)">
<head>

	<h1> Registration Page </h1> 
	 <title> Registration Page </title>
</head>

 <form method= "POST" action="#"> 
<p>
e-mail: <input type="text" name="email" value="" id="email" placeholder=" Email"  /> <br> <br>
username: <input type="text" name="username" value="" id="username" placeholder=" username"  /> <br> <br>	
password: <input type="password" name="password" value="" id="password" placeholder="Password" /> <br> <br>


</p>

<p class="submit">
    <input type="submit" name="submit" value="Register"  onclick="validate();   " ; />   
 
</p>
</form>

<script>
    function validate() {

    	if (document.getElementById("username").value == "" ) {
            alert("username may not be blank");
        } 
        if (document.getElementById("email").value == "") {
            alert("e-mail may not be blank");
        }  
        if (document.getElementById("password").value == "") {
           alert("Password may not be blank.");

        } 

var text= document.getElementById("email").value;
	var regx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(!(regx.test(text))){

alert("invalid mail format");

	}
	
}

    
</script>




</body>
</html>



<script>
<?php

session_start();
$con = mysqli_connect("localhost","root","","users");

if(!$con)
{
	echo "Database connection faild...";
}


if (isset($_POST['submit'])){


$email = $_POST['email'];
$username = $_POST['username'];
$pwd = $_POST['password'];
$password = MD5($pwd);


 if($email !=''&& $password !=''&&$username !='')
  {
    $query=mysqli_query($con,"SELECT * FROM tableofusers WHERE email='".$email."' and password='".$password."'") or die(mysqli_error());
    $res=mysqli_fetch_row($query);
    if($res)
    {
     echo 'repeated';
      alert("email or username already exists");

    }
     

$sql = "INSERT INTO tableofusers (email,username,password) VALUES ('$email','$username','$password')";

$result = mysqli_query($con, $sql);

if($result)
{
	
  	if($email && $username && $password != ''){
  	 header('location: welcome.php');
  	  $_SESSION['username   '] = $username;
  	// $_SESSION['email   '] = $email; 
   	//$_SESSION['   message '] = "You are now logged in";
  //	print_r( $_SESSION ); 
  	
  }
  	 else
  	 	alert("you must enter data");
}
else
{
	echo "Error :".$sql;
}
}

else
	 alert("enter data");

}
   
?>
</script>



