<!DOCTYPE html>
<html>

<head>
  <title> My Home Page </title>
</head>

<body style="background: url(https://cdn.pixabay.com/photo/2017/04/18/15/22/wild-horses-2239420_960_720.jpg)">

 <h1> Welcome to the Home Page  </h1>


      <label style=" color:blueviolet; font-size:larger;font-style:normal;font-weight: 900;font-weight: bold"> Click here if you want to register</label> <br> <br>

       <a href="register3.php">
        <button type="button" style="color: green; background-color: lightblue;" >Register </button> <br><br><br><br>

    </a>

    
<label style=" color:blueviolet; font-size:larger;font-style:normal;font-weight: 900;font-weight: bold"> Click here if you already have an account</label> <br> <br>

 <a href="login.php">
        <button type="button" style="color: green; background-color: lightblue ">Login </button> <br><br><br><br>

    </a>

  
       

</body>

</html>
