<!DOCTYPE html>
<html>

<head>
  <title> welcome </title>
</head>

<body style="background: url(https://ak9.picdn.net/shutterstock/videos/13334429/thumb/12.jpg)">

 <h1> Welcome  </h1>

<?php
session_start();

print_r( $_SESSION );
session_destroy();

	


     
?>
</body>

</html>
